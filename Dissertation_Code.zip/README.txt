1. Python notebook file is dedicated to each model
2. To run the code, open in Google Colab and simply run. It may ask for Google drive permissions. Always grant permissions.
3. There might be a chance for package error for pytorch which can be easily fixed by simply restarting the run time when asked for. 

Cheers!